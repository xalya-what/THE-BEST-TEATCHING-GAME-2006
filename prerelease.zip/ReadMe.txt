this game was made by xalya and living cheese.
this game is NOT auctually a teatching game but something simmalar to baldis bascis
i hope you enjoy this game i have been working on a while...
check out my youtube channel https://www.youtube.com/@Xalya_insanity
check out living cheese youtube channel https://www.youtube.com/@living_cheese
hope you dont anger pizzabox... because if you do... it will delete your game.
do not harass pizzabox he is just your computer.
there are a lot of hidden secrets i hope you can find them.
and remember that ilikeeatingpizza.